# serverSendEvent
serverSendEvent

This project was developped with server send event jersey sse


