package com.elfiady.event.web.event;

import org.glassfish.jersey.media.sse.EventOutput;


public class CustomEventOutput extends EventOutput {

    public CustomEventOutput() {
        super();
    }
}
